#example to run -  RunScript($CWD/iptv_maintenance.py)
from __future__ import unicode_literals
from collections import namedtuple
import codecs
import sys,os,json,urllib2
import xbmc, xbmcgui, xbmcaddon, xbmcplugin,re
import shutil
import time
import base64

import datetime
#import cookielib
#import pickle

# ?
import requests
import requests.packages.urllib3
requests.packages.urllib3.disable_warnings()


addon = 'Andy.plugin.program.Guide'
addon_name = addon
icon = xbmc.translatePath(os.path.join('special://home/addons', addon, 'icon.png'))
addonPath = xbmc.translatePath(os.path.join('special://home', 'addons', addon))
basePath = xbmc.translatePath(os.path.join('special://profile', 'addon_data', addon))
dbPath = xbmc.translatePath(xbmcaddon.Addon(addon).getAddonInfo('profile'))
blacklist = base64.b64decode(b'c2NyaXB0Lm9uLXRhcHAudHY=')
dialog = xbmcgui.Dialog();dp = xbmcgui.DialogProgress()
mode = 'ReplaceCREDENTIALS'




#GRAB POSSIBLE CREDENTIALS
def CREDENTIALS():
    xbmc.executebuiltin("ActivateWindow(busydialog)")
   
    '''
    #Get iptvsubs Pass
    addonSettingsFile = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'plugin.video.iptvsubs','settings.xml'))
    icon = xbmc.translatePath(os.path.join('special://home', 'addons', 'plugin.video.iptvsubs','icon.png'))
    if os.path.exists(addonSettingsFile):
        Source_File = os.path.join(basePath, 'addons.ini')
        tmp_File = os.path.join(basePath, '_backup.ini')
        if os.path.exists(Source_File):        
            addon_name2='plugin.video.iptvsubs';addon=xbmcaddon.Addon(addon_name2);user_name=addon.getSetting('kasutajanimi');pass_word=addon.getSetting('salasona')         
            user_name_old='iptvsubsemail@gmail.com'       
            pass_word_old='iptvsubspass' 
            addon_name2='plugin.video.iptvsubs';addon=xbmcaddon.Addon(addon_name2);user_name=addon.getSetting('kasutajanimi');pass_word=addon.getSetting('salasona') 
            ReplaceText(Source_File, tmp_File, user_name_old, user_name, pass_word_old, pass_word)
            #xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("IPTVSubs","User and Pass added to addons.ini",3000, icon))
            #
            #beta
            user_name_old='iptvsubsemail@gmail.com'       
            pass_word_old='iptvsubspass' 
            addon_name2='plugin.video.iptvsubs';addon=xbmcaddon.Addon(addon_name2);user_name=addon.getSetting('kasutajanimi');pass_word=addon.getSetting('salasona') 
            ReplaceText(Source_File, tmp_File, user_name_old, user_name, pass_word_old, pass_word)
            #xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("IPTVSubs","User and Pass added to addons.ini",3000, icon))        
            #
            import iptvsubsm3u
    '''    
    '''        
    #Get DexterTV Pass
    addonSettingsFile = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'plugin.video.dex','settings.xml'))
    icon = xbmc.translatePath(os.path.join('special://home', 'addons', 'plugin.video.dex','icon.png'))
    if os.path.exists(addonSettingsFile):
        username=addon.getSetting('kasutajanimi');password=addon.getSetting('salasona')       
        Source_File = os.path.join(basePath, 'addons.ini')
        tmp_File = os.path.join(basePath, '_backup.ini')
        if os.path.exists(Source_File):        
            user_name_old='dexteremail@gmail.com'
            pass_word_old='dexterpass'      
            addon_name2='plugin.video.dex';addon=xbmcaddon.Addon(addon_name2);user_name=addon.getSetting('kasutajanimi');pass_word=addon.getSetting('salasona') 
            ReplaceText(Source_File, tmp_File, user_name_old, user_name, pass_word_old, pass_word)
            #xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("DexterTV","User and Pass added to addons.ini",3000, icon))  
    '''  

    # or...

    # Grab iptvsubs Files
    addonPath = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'plugin.video.iptvsubs'))
    addonDestFile = os.path.join(addonPath, 'settings.xml')
    if os.path.exists(addonDestFile):
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("IPTVSUBS","M3U and addon.ini Credentials.",3000, icon))
        Name="iptvsubs";addon_name='plugin.video.iptvsubs';addon=xbmcaddon.Addon(addon_name)
        urlpath='http://2.welcm.tv:8000'
        username=addon.getSetting('kasutajanimi');password=addon.getSetting('salasona')
        groups = 'ENGLISH,SPORTS,FOR ADULTS'
        Run_scraper(urlpath,addon_name,username,password,Name,groups)


    # Grab DexterTV Files  no idea if this works i dont have a subscription
    addonPath = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'plugin.video.dex'))
    addonDestFile = os.path.join(addonPath, 'settings.xml')
    if os.path.exists(addonDestFile):
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("DEXTERTV","M3U and addon.ini Credentials.",3000, icon))
        Name="DexterTV";addon_name='plugin.video.dex';addon=xbmcaddon.Addon(addon_name)
        urlpath2 = addon.getSetting('lehekylg');urlpath=urlpath2+':8000'
        username=addon.getSetting('kasutajanimi');password=addon.getSetting('salasona')
        groups = '[COLOR oldlace][B]-- [COLOR deepskyblue]CANADA [COLOR oldlace]--[/B][/COLOR],[COLOR oldlace][B]-- [COLOR deepskyblue]USA [COLOR oldlace]--[/B][/COLOR],[COLOR oldlace][B]-- [COLOR deepskyblue]UK [COLOR oldlace]--[/B][/COLOR],[COLOR oldlace][B]-- [COLOR mediumpurple]KIDS [COLOR oldlace]--[/B][/COLOR],[COLOR oldlace][B]-- [COLOR mediumpurple]NEWS [COLOR oldlace]--[/B][/COLOR],[COLOR oldlace][B]-- [COLOR mediumpurple]SPORTS [COLOR oldlace]--[/B][/COLOR]'
        Run_scraper(urlpath,addon_name,username,password,Name,groups)

     
    '''
    # Grab iptvsubs Beta Files    wip
    # 88888.se:8000/panel_api.php?username=thankyouall&password=kodibeta
    # urlpath+"/panel_api.php?username=thankyouall&password=kodibeta
    #iptvsubs beta Pass
    addonPath = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'plugin.video.ruyaiptv'))
    addonDestFile = os.path.join(addonPath, 'settings.xml')
    if os.path.exists(addonDestFile):
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("IPTVSUBS Beta","M3U and addon.ini Credentials.",3000, icon))
        Name="iptvsubsbeta";addon_name='plugin.video.ruyaiptv';addon=xbmcaddon.Addon(addon_name)
        urlpath='http://bullsiptv.se:9850'
        #urlpath='http://88888.se:8000'
        #urlpath2 = addon.getSetting('server');urlpath=urlpath2   #  server  is   88888.se:8000
        username=addon.getSetting('username');password=addon.getSetting('password')
        groups = 'All channels'
        Run_scraper(urlpath,addon_name,username,password,Name,groups)
    '''

    Builtin()

    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("Updated","M3U and addon.ini Credentials.",3000, icon))


    xbmc.executebuiltin('Dialog.Close(busydialog)')    
    #sys.exit()
     


def Builtin():
    addon = 'Andy.plugin.program.Guide';addon_name = addon

    ####Create ini files####
    inipath = xbmc.translatePath(os.path.join('special://profile', 'addon_data', addon,'ini'))

    addonSettingsFile = xbmc.translatePath(os.path.join('special://home', 'addons', addon,'z0.py'))
    if os.path.exists(addonSettingsFile):
        try:
            if not os.path.exists(inipath):
                os.makedirs(inipath) 
                xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("z0","M3U and addon.ini Credentials.",3000, icon))
            import z0
            z0.z00() 
            #'''
            addonSettingsFile = xbmc.translatePath(os.path.join(inipath,'pvr.ini'))
            if os.path.exists(addonSettingsFile):
                 Source_File = addonSettingsFile
                 tmp_File = os.path.join(basePath, 'backup.ini')
                 user_name_old=blacklist
                 user_name='pvr.iptvsimple'
                 pass_word_old=''
                 pass_word=''
                 ReplaceText(Source_File, tmp_File, user_name_old, user_name, pass_word_old, pass_word)
                 #
                 Dest_File = os.path.join(basePath, 'addons.ini')
                 if os.path.exists(Dest_File):
                     AppendText(Source_File, Dest_File)
                 #
                 #Dest_File = os.path.join(basePath, 'addons2.ini')
                 #if os.path.exists(Dest_File):
                 #    AppendText(Source_File, Dest_File)
                 #               
                 if os.path.exists(Source_File): os.remove(Source_File)#Removes ini
            #'''
        except: pass


    addonSettingsFile = xbmc.translatePath(os.path.join('special://home', 'addons', addon,'z1.py'))
    if os.path.exists(addonSettingsFile):
        try:
            if not os.path.exists(inipath):
                os.makedirs(inipath) 
            xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("z1","M3U and addon.ini Credentials.",3000, icon))
            import z1
            #z1.z11()
            if os.path.exists(inipath):  shutil.rmtree(inipath)
        except: pass
    #
    addonSettingsFile = xbmc.translatePath(os.path.join('special://home', 'addons', addon,'z2.py'))
    if os.path.exists(addonSettingsFile):
        try:
            if not os.path.exists(inipath):
                os.makedirs(inipath) 
            xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("z2","M3U and addon.ini Credentials.",3000, icon))
            import z2
            z2.z22()
            if os.path.exists(inipath):  shutil.rmtree(inipath)
        except: pass
    #
    addonSettingsFile = xbmc.translatePath(os.path.join('special://home', 'addons', addon,'z3.py'))
    if os.path.exists(addonSettingsFile):
        try:
            if not os.path.exists(inipath):
                os.makedirs(inipath) 
            xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("z3","M3U and addon.ini Credentials.",3000, icon))
            import z3
            z3.z33()
            if os.path.exists(inipath):  shutil.rmtree(inipath)
        except: pass
    
    if os.path.exists(inipath):  shutil.rmtree(inipath)




# Create files
def Run_scraper(urlpath,addon_name,username,password,Name,groups):
    panel_url = urlpath+"/panel_api.php?username={}&password={}".format(username, password)  
    u = urllib2.urlopen(panel_url)
    j = json.loads(u.read())
    #
    # Channel ID Map
    my_map = {}    
    '''
    my_map = {"TREEHOUSE HD (NA)":"I80173.labs.zap2it.com",
              "FAMILY HD (NA)":"I70520.labs.zap2it.com",
              }
    '''          
    map_file =''
    if map_file:
      with open(map_file) as f:
        for line in f:
          sp_line = line.rstrip(os.linesep).split("\t")
          my_map[sp_line[0]] = sp_line[1]
    #
    # Renames channels as they are downloaded
    channelname_map = {"5*":"5Star", 
                       #"welcm":"welcmm",
                       #"3E HD":"3e",
                       "5STAR MAX HD - NEW":"5StarMax",
                       "A+E HD":"A&E",
                       "5 Star":"5Star",
                       "ABC HD EAST":"ABC HD",                       
                       "ABC HD WEST - NEW":"ABC West",                      
                       "ABC NEWS":"ABC News",                       
                       "ACTION HD":"ACTION",
                       "ACTION MAX HD - NEW":"ActionMax",                       
                       "ALJAZEERA ENGLISH":"Aljazeera",                      
                       "AMAZING DISCOVERIES":"Amazing Discoveries",                       
                       "AMAZING FACTS":"Amazing Facts",    
                       "ANIMAL PLANET HD":"Animal Planet", 
                       "BBC AMERICA HD":"BBC America",
                       "BBC NEWS":"BBC News", 
                       "BBC One HD":"BBC1",
                       "BBC Two HD":"BBC2",
                       "BBC Three HD":"BBC3",
                       "BBC Four HD":"BBC4", 
                       "BC1 HD - NEW":"BC1", 
                       "BET HD":"BET",
                       "BLOOMBERG":"Bloomberg", 
                       "BNN HD - NEW":"BNN", 
                       "BOUNCE HD":"Bounce",
                       "BRAVO HD":"Bravo",
                       "CARTOON NETWORK HD (NA)":"Cartoon Network", 
                       "CBC EAST HD":"CBC", 
                       "CBC NEWS HD":"CBC News",
                       "CBC VANCOUVER HD- NEW":"CBC Vancouver", 
                       "CBS HD EAST":"CBS HD", 
                       "CBS HD WEST - NEW":"CBS West",
                       "CBS NEWS HD":"CBS News",
                       "CHCH HD":"CHCH",
                       "CINEMAX EAST HD - NEW":"Cinemax", 
                       "CITY TV HD":"City TV Toronto",
                       "CITY VANCOUVER HD - NEW":"City TV Vancouver", 
                       "CNBC HD":"CNBC", 
                       "CNN HD":"CNN",
                       #"COMEDY NETWORK HD":"Comedy Network",
                       "COMEDY NETWORK HD":"Comedy Central",
                       "CP24 HD":"CP24",
                       "CTV EAST HD":"CTV Toronto", 
                       "CTV NORTH":"CTV North",
                       "CTV VANCOUVER HD - NEW":"CTV Vancouver", 
                       "CW11 HD":"CW", 
                       "DISCOVERY HD":"Discovery",
                       "DISCOVERY SCIENCE HD":"Discovery Science",
                       "DISNEY HD EAST":"Disney",
                       "DISNEY XD HD (NA)":"Disney XD", 
                       "E! HD":"E!",
                       "ENCORE WESTERN HD - NEW":"Encore Western", 
                       "FAMILY HD (NA)":"FAMILY", 
                       "FOOD HD":"Food Network",
                       "FOX HD EAST":"FOX HD",
                       "FOX HD WEST - NEW":"FOX West",    
                       "FOX NEWS HD":"FOX News", 
                       "FX HD":"FX",
                       "FXX HD":"FXX", 
                       "GLOBAL BC HD - NEW":"Global Vancouver", 
                       "GLOBAL EAST HD":"Global Toronto",
                       "HALLMARK HD":"Hallmark",
                       "HBO COMEDY HD":"HBO Comedy", 
                       "HBO EAST HD":"HBO HD", 
                       "HBO SIGNATURE HD":"HBO Signature",
                       "HGTV HD":"HGTV", 
                       "HISTORY HD":"History", 
                       "HLN HD":"HLN",
                       "HSN 2":"HSN2",                       
                       "ID HD":"Discovery Investigation",
                       "IFC HD":"IFC",    
                       "LIFE HD":"Lifetime", 
                       "LIFETIME MOVIES HD":"LMN",
                       "MOREMAX HD - NEW":"MoreMax", 
                       "MOVIE TIME HD":"MovieTime", 
                       "MSNBC HD":"MSNBC",
                       "MTV HD":"MTV",
                       "NAT GEO HD":"National Geographic", 
                       "NAT GEO WILD HD":"Nat Geo Wild", 
                       "NBC HD EAST":"NBC HD",
                       "NBC HD WEST - NEW":"NBC West", 
                       "NICKELODEON HD (NA)":"Nickelodeon", 
                       "OMNI 1 HD":"OMNI 1",
                       "OMNI 2 HD":"OMNI 2",
                       "OWN HD":"OWN",    
                       "PBS HD":"PBS", 
                       "REV'N USA HD":"Rev USA",
                       "RT DOCUMENTARY HD":"RT Documentary", 
                       "RT NEWS HD":"RT News", 
                       "SHOWCASE HD":"SHOWCASE",
                       "SHOWTIME EAST":"Showtime HD",
                       "SHOWTIME SHOWCASE HD":"Showtime Showcase", 
                       "SKY CBBC HD":"CBBC", 
                       "SKY DISNEY JR (UK)":"Disney Jr UK",
                       "SKY DISNEY XD (UK)":"Disney XD UK", 
                       "SKY NEWS HD":"Sky News", 
                       "SKY NICK (UK)":"Nickelodeon UK",
                       "SKY NICK TOONS (UK)":"Nick Toons UK",
                       "SLICE HD":"SLICE",    
                       "SPIKE HD":"Spike", 
                       "STARZ BLACK HD":"Starz In Black",
                       "STARZ COMEDY HD - NEW":"Starz Comedy", 
                       "STARZ EDGE HD":"Starz Edge", 
                       "STARZ HD":"Starz",
                       "STARZ KIDZ HD - NEW":"Starz Kids",
                       "Sky 3E":"3E", 
                       "Sky Alibi":"Alibi", 
                       "Sky Animal Planet":"Animal Planet UK",
                       "Sky Channel 4":"Channel 4", 
                       "Sky Channel 5":"Channel 5", 
                       "Sky Comedy Network":"Comedy Central UK",
                       "Sky Crime and Investigation":"Crime and Investigation",
                       "Sky Dave":"Dave",    
                       "Sky Discovery":"Discovery UK", 
                       "Sky Discovery History":"Discovery History",
                       "Sky Discovery Science":"Discovery Science UK", 
                       "Sky Discovery Shed":"Discovery Shed", 
                       "Sky Discovery Turbo":"Discovery Turbo",
                       "Sky Discovery investigation":"Discovery Investigation UK",
                       "Sky Eden":"Eden", 
                       "Sky Film 4":"Film4", 
                       "Sky Food":"Food UK",
                       "Sky Gold":"Gold", 
                       "Sky Home":"Home", 
                       "Sky Movie Romance":"Sky Movies Drama",
                       "Sky Movies Atlantic":"Sky Atlantic",    
                       "Sky Movies Sci-Fi":"Sky Movies Scifi", 
                       "Sky Natgeo":"National Geographic UK",
                       "SKY News":"Sky News",
                       "Sky One":"Sky1", 
                       "Sky Quest":"Quest", 
                       "Sky RTE 1":"RTE1",
                       "Sky RTE 2":"RTE2",
                       "Sky Watch":"Watch",  
                       "Sky Yesterday":"Yesterday", 
                       "Sky itv1":"ITV1",
                       "Sky itv2":"ITV2", 
                       "Sky itv3":"ITV3",
                       "Sky itv4":"ITV4",
                       "SyFy HD":"Syfy",
                       "TBS HD":"TBS",    
                       "TCM EAST HD":"TCM", 
                       "TCM HD":"TCM",
                       "THRILLER MAX HD - NEW":"ThrillerMax", 
                       "TLC HD":"TLC", 
                       "TNT HD":"TNT",
                       "TRAVEL HD":"Travel",
                       "TREEHOUSE HD (NA)":"TREEHOUSE", 
                       "TRU TV HD":"truTV", 
                       "TV LAND HD":"TV Land",
                       "TVO HD (NA)":"TVO", 
                       "USA NETWORK HD":"USA Network", 
                       "VELOCITY HD":"VELOCITY",
                       "VEVO 1 HD":"VEVO1",
                       "VEVO 2 HD":"VEVO2",    
                       "VH1 HD":"VH1",    
                       "VICELAND HD":"Viceland", 
                       "W MOVIES HD":"W MOVIES",
                       "W NETWORK HD":"W NETWORK", 
                       "WE TV HD":"WE TV", 
                       "WEATHER CANADA HD":"Weather Canada",
                       "WEATHER USA HD":"Weather USA",
                       "WIN TV HD":"WIN TV",
                       "YTV HD (NA)":"YTV",
                       "Astro Supersports 1 HD":"Astro SuperSport 1", 
                       "Astro Supersports 2 HD":"Astro SuperSport 2", 
                       "Astro Supersports 3 HD":"Astro SuperSport 3",                        
                       "Astro Supersports 4 HD":"Astro SuperSport 4",                         
                       #"Astro Supersports 1 HD":"Astro Supersports 1", 
                       #"Astro Supersports 2 HD":"Astro Supersports 2", 
                       #"Astro Supersports 3 HD":"Astro Supersports 3",                        
                       #"Astro Supersports 4 HD":"Astro Supersports 4",                    
                       "BEIN HD":"BEINS1", 
                       "CBS SPORTS HD":"CBS Sports",
                       "ESPN HD":"ESPN",
                       "ESPN 2 HD":"ESPN2",    
                       "FOX SPORTS 1 HD":"Fox Sports 1 HD", 
                       "FOX SPORTS 2 HD":"Fox Sports 2 HD",
                       "GOLF HD":"Golf Channel", 
                       "MLB HD 01":"MLB1", 
                       "MLB HD 02":"MLB2", 
                       "MLB HD 03":"MLB3",                       
                       "MLB HD 04":"MLB4",                        
                       "MLB HD 05":"MLB5", 
                       "MLB HD 06":"MLB6",                        
                       "MLB HD 07":"MLB7",                        
                       "MLB HD 08":"MLB8",                       
                       "MLB HD 09":"MLB9",                        
                       "MLB HD 10":"MLB10",                       
                       "MLB HD 11":"MLB11",                       
                       "MLB HD 12":"MLB12",                      
                       "MLB NETWORK":"MLB Network",
                       "NBA HD":"NBA TV",
                       "NBC SPORTS":"NBCSN", 
                       "NFL NOW HD":"NFL NOW",
                       "NHL NETWORK HD":"NHL Network", 
                       "NHL ON VERSUS HD":"VERSUS", 
                       "SKY BOX NATION":"BoxNation",
                       "SKY BT 1":"BT Sport 1",
                       "SKY BT 2":"BT Sport 2",    
                       "SKY BT 1 HD":"BT Sport 1 HD",
                       "SKY BT 2 HD":"BT Sport 2 HD",
                       "Sky Sports News HD":"Sky Sports News", 
                       "SKY SPORTS 1":"Sky Sports 1 HD", 
                       "SKY SPORTS 2":"Sky Sports 2 HD", 
                       "SKY SPORTS 3":"Sky Sports 3 HD",                        
                       "SKY SPORTS 4":"Sky Sports 4 HD",                       
                       "SKY SPORTS 5":"Sky Sports 5 HD",                       
                       "SONY ESPN HD - LIVE EVENTS":"PPV",
                       #"SPORT TIME TV 1HD":"SPORT TIME TV 1HD", 
                       "SPORTSNET 360":"Sportsnet 360", 
                       "SPORTSNET ONE HD":"Sportsnet One",
                       "SPORTSNET ONT":"Sportsnet Ontario",
                       "SPORTSNET WORLD HD":"Sportsnet World", 
                       "Sky Sports News HD":"Sky Sports News HD",
                       "Sony Six HD":"Sony Six", 
                       "TEN CRICKET HD":"TEN Cricket", 
                       "TENNIS HD":"Tennis Channel",
                       "TSN 1 HD":"TSN1",
                       "TSN 2 HD":"TSN2",
                       "TSN 3 HD":"TSN3",                       
                       "TSN 4 HD":"TSN4",                       
                       "TSN 5 HD":"TSN5",                      
                       "WILLOW CRICKET HD":"WILLOW CRICKET",    
                       "WWE HD":"WWE Network", 
                       "W NETWORK":"W Network", 
                       "YANKEES HD - NEW":"YANKEES",
                       "HUSTLER HD":"HUSTLER", 
                       "PLAYBOY TV HD - NEW":"PLAYBOY", 
                       "VIVID TV - NEW":"VIVID"
                      }                      
    #channelname_map = {} 
    namemap_file = ''
    if namemap_file:
      with open(namemap_file) as f:
        for line in f:
          sp_line = line.rstrip(os.linesep).split("\t")
          channelname_map[sp_line[0]] = sp_line[1]
    inv_map = {v: k for k, v in my_map.items()}
    Channel = namedtuple('Channel', ['tvg_id', 'tvg_name', 'tvg_logo', 'group_title', 'channel_url'])
    channels = []
    online_groups = set()
    #
    # Grab Channels
    for ts_id, info in j["available_channels"].iteritems():
      #channel_url = "http://2.welcm.tv:8000/live/{}/{}/{}.m3u8".format(username, password, ts_id)
      #channel_url = urlpath+":8000/live/{}/{}/{}.m3u8".format(username, password, ts_id)
      channel_url = urlpath+"/live/{}/{}/{}.m3u8".format(username, password, ts_id)
      tvg_id = ""
      tvg_name = info['name']
      if info['epg_channel_id'] and info['epg_channel_id'].endswith(".com"):
        tvg_id = info['epg_channel_id']
      if tvg_name in my_map:
        tvg_id = my_map[tvg_name]
      tvg_logo = ""
      #if info['stream_icon']:
      #  tvg_logo = info['stream_icon']
      group_title = info['category_name']
      online_groups.add(group_title)
      if tvg_name in channelname_map:
        tvg_name = channelname_map[tvg_name]
      channels.append(Channel(tvg_id, tvg_name, tvg_logo, group_title, channel_url))
    #
    # Grab Groups
    wanted_groups = sorted(online_groups)
    if groups:
      wanted_groups = groups.split(',')
    group_idx = {group:idx for idx,group in enumerate(wanted_groups)}
    # Has error if channel listings is different 
    #sys.stderr.write("Channel groups: {}\n".format(",".join(wanted_groups)))
    wanted_channels = [c for c in channels if c.group_title in wanted_groups]
    wanted_channels.sort(key=lambda c: "{}-{}".format(group_idx[c.group_title], c.tvg_name))
    #
    # Sort Channels
    channel_fn = ''
    if channel_fn:
      #with open(channel_fn, 'w') as channel_f:
      with open(channel_fn, write_style) as channel_f:
        for c in wanted_channels:
          if c.tvg_id.endswith(".com"):
            if c.tvg_name in inv_map:
              channel_f.write("{}\n".format(inv_map[c.tvg_name]))
            else:
              channel_f.write("{}\n".format(c.tvg_id))

    #
    # Create m3u
    output_fn = Name + '.m3u'
    write_style = 'w'
    with codecs.open(dbPath + output_fn, write_style, 'utf-8') as f:     
      f.write('#EXTM3U\n#http://'+Name+'\n')
      for c in wanted_channels:
        #f.write('#EXTINF:-1 tvg-id="{0}" tvg-name="{1}" tvg-logo="{1}.png" group-title="{3}",{1}\n{4}\n'.format(c.tvg_id, c.tvg_name, c.tvg_logo, c.group_title, c.channel_url))
        #f.write('#EXTINF:-1 tvg-logo="{1}.png",{1}\n{4}\n'.format(c.tvg_id, c.tvg_name, c.tvg_logo, c.group_title, c.channel_url))
        f.write('#EXTINF:-1 tvg-id="{1}" tvg-name="{1}" tvg-logo="{1}.png" group-title="{3}",{1}\n{4}\n'.format(c.tvg_id, c.tvg_name, c.tvg_logo, c.group_title, c.channel_url))
    #
    Clean_Names(dbPath + output_fn, basePath+'/_iptvsubs.m3u') 
    #os.remove(basePath+'/_iptvsubs.m3u')
    #xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("TV Guide",args.output_fn+" done.",3000, icon))


    #
    # Create ini
    ini_file = 'addons.ini'
    write_style = 'a'
    with open(dbPath + ini_file, write_style) as f:
        f.write('['+addon_name+'] \n;'+Name+'\n')
        for c in wanted_channels:
            f.write('{1}={4}\n'.format(c.tvg_id, c.tvg_name, c.tvg_logo, c.group_title, c.channel_url))
    #            
    Clean_TS(dbPath + ini_file, basePath+'/_addons.ini') 
        #Clean_Names(dbPath + ini_file, basePath+'/_backup.ini')
        #xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("TV Guide",ini_file+" done.",3000, icon))
        #sys.exit()







def Clean_TS(Clean_Name,tmpFile):
    #tmpFile = os.path.join(basePath, '_backup.ini')
    if os.path.exists(tmpFile):
        os.remove(tmpFile)
    os.rename(Clean_Name, tmpFile)
    s=open(tmpFile).read()
    #
    s=s.replace('m3u8','ts')
    #
    f=open(Clean_Name,'a')
    f.write(s)
    f.close()
    os.remove(tmpFile)

def Clean_Names(Clean_Name,tmpFile):
    #tmpFile = os.path.join(basePath, '_backup.ini')
    if os.path.exists(tmpFile):
        os.remove(tmpFile)
    os.rename(Clean_Name, tmpFile)
    s=open(tmpFile).read()
    #
    s=s.replace('ABC HD.png','ABC_HD.png')
    s=s.replace('ABC West.png','ABC_West.png')
    s=s.replace('ABC News.png','ABC_News.png')
    s=s.replace('AMC HD.png','AMC_HD.png')
    s=s.replace('Animal Planet.png','Animal_Planet.png')
    s=s.replace('BBC America.png','BBC_America.png')
    s=s.replace('BBC News.png','BBC_News.png')
    s=s.replace('CBC News.png','CBC_News.png')
    s=s.replace('CBC Vancouver.png','CBC_Vancouver.png')
    s=s.replace('CBS HD.png','CBS_HD.png')
    s=s.replace('CBS West.png','CBS_West.png')
    s=s.replace('CBS News.png','CBS_News.png')
    s=s.replace('CCTV News.png','CCTV_News.png')     
    s=s.replace('CEEN TV.png','CEEN_TV.png')      
    s=s.replace('City TV Vancouver.png','City_TV_Vancouver.png')
    s=s.replace('CTV Regina.png','CTV_Regina.png')
    s=s.replace('CTV Toronto.png','CTV_Toronto.png')
    s=s.replace('CTV Vancouver.png','CTV_Vancouver.png')
    s=s.replace('CTV North.png','CTV_North.png')
    s=s.replace('Cartoon Network.png','Cartoon_Network.png')
    s=s.replace('City TV Toronto.png','City_TV_Toronto.png')
    s=s.replace('Comedy Central.png','Comedy_Central.png')
    s=s.replace('Comedy Central UK.png','Comedy_Central_UK.png')
    s=s.replace('Crime and Investigation.png','Crime_and_Investigation.png')
    s=s.replace('Discovery Science.png','Discovery_Science.png')
    s=s.replace('Discovery Science UK.png','Discovery_Science_UK.png')
    s=s.replace('Discovery History.png','Discovery_History.png')
    s=s.replace('Discovery Investigation.png','Discovery_Investigation.png')
    s=s.replace('Discovery Investigation UK.png','Discovery_Investigation_UK.png')
    s=s.replace('Discovery Shed.png','Discovery_Shed.png')
    s=s.replace('Discovery Turbo.png','Discovery_Turbo.png')
    s=s.replace('Discovery UK.png','Discovery_UK.png')
    s=s.replace('Disney XD.png','Disney_XD.png')
    s=s.replace('Disney XD UK.png','Disney_XD_UK.png')
    s=s.replace('Disney Jr UK.png','Disney_Jr_UK.png')
    s=s.replace('Encore Western.png','Encore_Western.png')
    s=s.replace('FOX HD.png','FOX_HD.png')
    s=s.replace('FEVA TV.png','FEVA_TV.png')
    s=s.replace('FOX West.png','FOX_West.png')
    s=s.replace('FOX News.png','FOX_News.png')
    s=s.replace('Food Network.png','Food_Network.png')
    s=s.replace('Food UK.png','Food_UK.png')
    s=s.replace('Fox News.png','Fox_News.png')
    s=s.replace('Global Vancouver.png','Global_Vancouver.png')
    s=s.replace('Global Toronto.png','Global_Toronto.png')
    s=s.replace('HBO Comedy.png','HBO_Comedy.png')
    s=s.replace('HBO HD.png','HBO_HD.png')
    s=s.replace('HBO Signature.png','HBO_Signature.png')
    s=s.replace('Movie Time.png','Movie_Time.png')
    s=s.replace('NBC HD.png','NBC_HD.png')
    s=s.replace('NBC West.png','NBC_West.png')
    s=s.replace('Nat Geo Wild.png','Nat_Geo_Wild.png')
    s=s.replace('National Geographic.png','National_Geographic.png')
    s=s.replace('Nick Toons UK.png','Nick_Toons_UK.png')       
    s=s.replace('OMNI 1.png','OMNI_1.png')      
    s=s.replace('OMNI 2.png','OMNI_1.png')   
    s=s.replace('RT Documentary.png','RT_Documentary.png')     
    s=s.replace('RT News.png','RT_News.png')  
    s=s.replace('Rev USA.png','Rev_USA.png')
    s=s.replace('Sky News.png','Sky_News.png')
    s=s.replace('Starz In Black.png','Starz_In_Black.png')
    s=s.replace('Starz Comedy.png','Starz_Comedy.png')
    s=s.replace('Starz Edge.png','Starz_Edge.png')
    s=s.replace('Starz Kids & Family.png','Starz_Kids_&_Family.png')
    s=s.replace('Showtime HD.png','Showtime_HD.png')
    s=s.replace('Showtime Showcase.png','Showtime_Showcase.png')
    s=s.replace('Animal Planet UK.png','Animal_Planet_UK.png')
    s=s.replace('Channel 4.png','Channel_4.png')
    s=s.replace('Channel 5.png','Channel_5.png')
    s=s.replace('Discovery History UK.png','Discovery_History_UK.png')
    s=s.replace('Discovery Science.png','Discovery_Science.png')
    s=s.replace('Discovery Investigation.png','Discovery_Investigation.png')
    s=s.replace('Sky Atlantic.png','Sky_Atlantic.png')
    s=s.replace('Sky Movies Drama.png','Sky_Movies_Drama.png')
    s=s.replace('Sky Movies Action.png','Sky_Movies_Action.png')
    s=s.replace('Sky Movies Comedy.png','Sky_Movies_Comedy.png')
    s=s.replace('Sky Movies Disney.png','Sky_Movies_Disney.png')
    s=s.replace('Sky Movies Family.png','Sky_Movies_Family.png')
    s=s.replace('Sky Movies Premiere.png','Sky_Movies_Premiere.png')
    s=s.replace('Sky Movies Scifi.png','Sky_Movies_Scifi.png')
    s=s.replace('Sky Movies Select.png','Sky_Movies_Select.png')
    s=s.replace('Sky Movies Showcase.png','Sky_Movies_Showcase.png')
    s=s.replace('Starz Kids.png','Starz_Kids.png')
    s=s.replace('National Geographic UK.png','National_Geographic_UK.png')
    s=s.replace('TV Land.png','TV_Land.png')
    s=s.replace('TV JAMAICA.png','TV_JAMAICA.png')
    s=s.replace('Travel XP.png','Travel_XP.png')
    s=s.replace('USA Network.png','USA_Network.png')
    s=s.replace('W MOVIES.png','W_MOVIES.png')
    s=s.replace('WE TV.png','WE_TV.png')
    s=s.replace('WE NETWORK.png','WE_NETWORK.png')
    s=s.replace('Weather Canada.png','Weather_Canada.png')
    s=s.replace('Weather USA.png','Weather_USA.png')
    s=s.replace('WIN TV.png','WIN_TV.png')
    s=s.replace('ASTRO CRICKET HD.png','ASTRO_CRICKET_HD.png')
    s=s.replace('Arena Sports 1 HD.png','Arena_Sports_1_HD.png')     
    s=s.replace('Arena Sports 2 HD.png','Arena_Sports_2_HD.png')      
    s=s.replace('Arena Sports 3 HD.png','Arena_Sports_3_HD.png') 
    s=s.replace('Arena Sports 4 HD.png','Arena_Sports_4_HD.png')    
    s=s.replace('Astro SuperSport 1.png','Astro_SuperSport_1.png')
    s=s.replace('Astro SuperSport 2.png','Astro_SuperSport_2.png')
    s=s.replace('Astro SuperSport 3.png','Astro_SuperSport_3.png')
    s=s.replace('Astro SuperSport 4.png','Astro_SuperSport_4.png')
    s=s.replace('Fox Sports 1 HD.png','Fox_Sports_1_HD.png')
    s=s.replace('Fox Sports 2 HD.png','Fox_Sports_2_HD.png')
    s=s.replace('Golf Channel.png','Golf_Channel.png')
    s=s.replace('MLB Network.png','MLB_Network.png')
    s=s.replace('NBA TV.png','NBA_TV.png')
    s=s.replace('NFL Network.png','NFL_Network.png')
    s=s.replace('NHL Network.png','NHL_Network.png')
    s=s.replace('BT Sport 1.png','BT_Sport_1.png')
    s=s.replace('BT Sport 2.png','BT_Sport_2.png')
    s=s.replace('BT Sport 1 HD.png','BT_Sport_1_HD.png')
    s=s.replace('BT Sport 2 HD.png','BT_Sport_2_HD.png')
    s=s.replace('BT SPORTS ESPN.png','BT_SPORTS_ESPN.png')
    s=s.replace('BT SPORTS EUROPE.png','BT_SPORTS_EUROPE.png')
    s=s.replace('CBS Sports.png','CBS_Sports.png')
    s=s.replace('CTH 1 HD.png','CTH_1_HD.png') 
    s=s.replace('CTH 2 HD.png','CTH_2_HD.png')  
    s=s.replace('CTH 3 HD.png','CTH_3_HD.png')  
    s=s.replace('CTH 4 HD.png','CTH_4_HD.png') 
    s=s.replace('CTH 5 HD.png','CTH_5_HD.png')      
    s=s.replace('CTH XD HD.png','CTH_XD_HD.png')
    s=s.replace('FOX SPORTS 1 ASIA.png','FOX_SPORTS_1_ASIA.png')   
    s=s.replace('FOX SPORTS 2 ASIA.png','FOX_SPORTS_2_ASIA.png')
    s=s.replace('FOX SPORTS 3 ASIA.png','FOX_SPORTS_3_ASIA.png')
    s=s.replace('MOTO GP.png','MOTO_GP.png') 
    s=s.replace('NFL NOW.png','NFL_NOW.png') 
    s=s.replace('PREMIER SPORTS.png','PREMIER_SPORTS.png')                     
    s=s.replace('Setanta Asia HD.png','Setanta_Asia_HD.png')
    s=s.replace('Sky Sports News.png','Sky_Sports_News.png')
    s=s.replace('Sky Sports 1 HD.png','Sky_Sports_1_HD.png')
    s=s.replace('Sky Sports 2 HD.png','Sky_Sports_2_HD.png')
    s=s.replace('Sky Sports 2 HD.png','Sky_Sports_2_HD.png')
    s=s.replace('Sky Sports 3 HD.png','Sky_Sports_3_HD.png')
    s=s.replace('Sky Sports 4 HD.png','Sky_Sports_4_HD.png')
    s=s.replace('Sky Sports 5 HD.png','Sky_Sports_5_HD.png')
    s=s.replace('Sky Sports F1.png','Sky_Sports_F1.png')
    s=s.replace('Sky Sports News.png','Sky_Sports_News.png')
    s=s.replace('Sony Six.png','Sony_Six.png')
    s=s.replace('Sportsnet 360.png','Sportsnet_360.png')
    s=s.replace('Sportsnet One.png','Sportsnet_One.png')
    s=s.replace('Sportsnet Ontario.png','Sportsnet_Ontario.png')
    s=s.replace('Sportsnet World.png','Sportsnet_World.png')
    s=s.replace('Tennis Channel.png','Tennis_Channel.png')
    s=s.replace('TEN Cricket.png','TEN_Cricket.png')
    s=s.replace('WWE Network.png','WWE_Network.png')
    s=s.replace('WILLOW CRICKET.png','WILLOW_CRICKET.png')
    #
    #if args.ini_file:
    #    s=s.replace('m3u8','ts')


    f=open(Clean_Name,'a')
    f.write(s)
    f.close()
    os.remove(tmpFile)
     
    #if os.path.exists(Clean_Name):
    #    if os.path.exists(tmpFile):        
    #        os.remove(tmpFile)


    #getridof = os.path.join(basePath, '_iptvsubs.m3u')
    #if os.path.exists(getridof):        
    #    os.remove(getridof)


    #m3uPath = xbmc.translatePath(os.path.join('special://profile','playlists', 'video', 'iptvsubs.m3u'))   
    #Clean_Names(dbPath + args.output_fn, m3uPath)   

    #if os.path.exists(s):
        #m3uSourcePath = xbmc.translatePath(os.path.join('special://profile','addon_data', addon, 'iptvsubs.m3u')) 
        #m3uDestPath = xbmc.translatePath(os.path.join('special://profile','playlists', 'video', 'iptvsubs.m3u')) 
        #m3uDestPath = 'special://videoplaylists/iptvsubs.m3u'
        #n=open(s).read()
        #f=open(m3uDestPath,'a')
        #f.write(n)
        #f.close()


    #xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("TV Guide","Done.",3000, icon))
     
     


def AppendText(SourceFile, DestFile):
    s=open(SourceFile).read()
    f=open(DestFile,'a')
    f.write(s)
    f.close()
    #if os.path.exists(tmpFile):        
    #    os.remove(tmpFile)
    #xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("TV Guide","Done.",3000, icon))

def ReplaceText(SourceFile, tmpFile, usernameold, username, passwordold, password):
    if os.path.exists(tmpFile):
        os.remove(tmpFile)
    os.rename(SourceFile, tmpFile)
    s=open(tmpFile).read()

    s=s.replace(usernameold,username)
    s=s.replace(passwordold,password)
    f=open(SourceFile,'a')
    f.write(s)
    f.close()
    os.remove(tmpFile)
    #xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("TV Guide","Extra User and Pass added to ini",3000, icon))
         
if mode=='ReplaceCREDENTIALS' : CREDENTIALS()
